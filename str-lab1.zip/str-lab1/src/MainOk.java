
public class MainOk {

	public static void main(String[] args) {
		SomadorVetor sv = new SomadorVetor();
		int vetor1[] = new int[1_000_000_000];
		sv.preencherVetorInteiro(vetor1);
		long soma1 = sv.somarInteiros(vetor1);
		print(soma1);
		vetor1 = null;
		float vetor2[] = new float[1_000_000_000];
		sv.preencherVetorFloat(vetor2);
		float soma2 = sv.somarFloats(vetor2);
		print(soma2);

	}
	
	public  static void print(long s) {
		System.out.println("Soma Int: " + s);
	}
	
	public  static void print(float s) {
		System.out.println("Soma Float: " + s);
	}

}
