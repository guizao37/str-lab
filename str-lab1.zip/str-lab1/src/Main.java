
public class Main extends Thread {

	public static void main(String[] args) {

		SomadorVetor sv = new SomadorVetor();
		
		Runnable t1 = new Runnable() {
			public void run() {

				int vetor1[] = new int[100000000];
				sv.preencherVetorInteiro(vetor1);
				long soma1 = sv.somarInteiros(vetor1);
				print(soma1);
				vetor1 = null;
			}
		};
		Runnable t2 = new Runnable() {
			public void run() {
				float vetor2[] = new float[100000000];
				sv.preencherVetorFloat(vetor2);
				float soma2 = sv.somarFloats(vetor2);
				print(soma2);
			}
		};
		
		t1.run();
		t2.run();
	}

	public  static void print(long s) {
		System.out.println("Soma Int: " + s);
	}
	public  static void print(float s) {
		System.out.println("Soma Float: " + s);
	}

}