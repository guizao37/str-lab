
public class SomadorVetorOK {
	
	long somarInteiros(int[] vetor) {
		if (vetor == null) {
			return 0;
		}
		if (vetor.length == 0) {
			return 0;
		}
		long soma = 0;
		for (int i = 0; i < vetor.length; i++) {
			soma += vetor[i];
		}
		return soma;
	}
	
	float somarFloats(float[] vetor) {
		if (vetor == null) {
			return 0;
		}
		if (vetor.length == 0) {
			return 0;
		}
		float soma = 0;
		for (int i = 0; i < vetor.length; i++) {
			soma += vetor[i];
		}
		return soma;
	}

	void preencherVetorInteiro(int[] vetor) {
		if (vetor == null) {
			return;
		}
		if (vetor.length == 0) {
			return;
		}

		for (int i = 0; i < vetor.length; i++) {
			vetor[i] = i;
		}
		
	}
	
	void preencherVetorFloat(float[] vetor) {
		if (vetor == null) {
			return;
		}
		if (vetor.length == 0) {
			return;
		}

		for (int i = 0; i < vetor.length; i++) {
			vetor[i] = i;
		}
		
	}

}
